# Piano operativo — Bankroll virtuale

## Stato verificato 2026-11-06
- Repository: frank67-bot/Bankroll-virtuale-nuovo, branch main, pubblico.
- README.md iniziale presente.
- Lettura via integrazione ChatGPT funzionante.
- Scrittura via integrazione bloccata: HTTP 403 Resource not accessible by integration.
- Nessun file del pacchetto e stato caricato sul repository.

## Fasi
1. Importare i file di questo pacchetto nel repository, senza sovrascrivere il README esistente senza revisione.
2. Registrare provenienza, stagioni e schema dei CSV Serie A.
3. Pulizia e controllo quote pre-match; controllare duplicati, date e risultati.
4. Stimare probabilita indipendenti con separazione cronologica train/validation/test.
5. Calcolare ROI atteso e regole di stake virtuale; applicare limiti di esposizione.
6. Backtest walk-forward e confronto con baseline mercato senza margine.
7. Report con campione, Brier score, log loss, ROI, drawdown e intervalli d'incertezza.

## Criteri di sicurezza e qualita
- Non usare denaro reale o credenziali nel repository.
- Nessuna value bet senza quote datate, probabilita modello validate e timestamp pre-partita.
- Registrare anche NO BET e dati mancanti.
- Non dichiarare profitto o affidabilita senza backtest fuori campione.

## Importazione via browser GitHub
Aprire il repository, selezionare Add file > Upload files, estrarre prima lo ZIP e caricare i file mantenendo la struttura delle cartelle. Non caricare __pycache__ o .pyc. Il file README.md gia presente va gestito separatamente.
