# Bankroll virtuale — versione iniziale

Progetto sperimentale di analisi Serie A. Nessuna scommessa reale.

## Componenti
- `src/bankroll.py`: rimozione proporzionale del margine del bookmaker, ROI atteso secondo un modello indipendente e frazione di Kelly teorica.
- `tests/test_bankroll.py`: test automatici delle funzioni base.
- `data/`: destinazione dei dati storici, da documentare con fonte e data.

## Eseguire i test
Dalla cartella principale:

```bash
python -m unittest discover -s tests -v
```

## Avvertenze
Le probabilità di mercato normalizzate NON sono probabilità reali accertate e NON costituiscono un modello predittivo indipendente. Prima di qualsiasi valutazione di performance occorrono dati storici, separazione temporale training/test, controllo delle quote pre-match e simulazione senza look-ahead bias.
